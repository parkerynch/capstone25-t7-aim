/**
 * `hello-api.ts`
 * - service endpoint for `/hello`
 *
 *
 * @author      Steve Jung <steve@lemoncloud.io>
 * @date        2025-10-10 initial version with `lemon-core#4.0.7`
 *
 * @copyright   (C) lemoncloud.io 2025 - All Rights Reserved. (https://eureka.codes)
 */
import { View, CoreModel } from 'lemon-model';
import { $T, $U, _log, NextHandler, GeneralWEBController } from 'lemon-core';
import { TestView } from '../service/views';
import $service, { HelloService } from '../service/service';
const NS = $U.NS('hello', 'yellow'); // NAMESPACE TO BE PRINTED.

/* eslint-disable @typescript-eslint/no-unused-vars */
/**
 * class: `HelloAPIController`
 * - handle of `/hello` type
 *
 * support basic CRUD operations.
 * - GET    /hello         => list-all
 * - GET    /hello/:id     => get-one
 * - POST   /hello/:id     => create-new (at position :id)
 * - PUT    /hello/:id     => update-existing (at position :id)
 * - DELETE /hello/:id     => delete-existing (at position :id)
 * - GET    /hello/:id/say => get-one with say command.
 */
export class HelloAPIController extends GeneralWEBController {
    /**
     * default constructor.
     */
    public constructor(readonly service: HelloService = $service) {
        super('hello');
        _log(NS, `HelloAPIController()...`);
    }

    /**
     * name of this resource.
     */
    public hello = () => `hello-api-controller:${this.type()}`;

    /**
     * transform from model to view.
     */
    public modelAsView = <V extends View, M = CoreModel<any>>(model: M) => $U.cleanup({ ...model }) as V;

    /**
     * list hello
     *
     * ```sh
     * $ http ':8000/hello'
     */
    public doList: NextHandler = async (id, param, body, context) => {
        const errScope = `doList(${this.type()}/${id ?? ''})`;
        _log(NS, `${errScope} ...`);
        throw new Error(`NOT IMPLEMENTED - ${errScope}`);
    };

    /**
     * get hello hello
     *
     * ```sh
     * $ http ':8000/hello/0'
     * $ http ':8000/hello/abc'
     */
    public doGet: NextHandler = async (id, param, body, context) => {
        const errScope = `doGet(${this.type()}/${id ?? ''})`;
        _log(NS, `${errScope} ...`);
        id = id === '0' ? '' : $T.S2(id);
        if (!id) return { message: this.hello(), timestamp: $U.ts() };

        //* read from database.
        if (/^[a-zA-Z]+$/.test(id)) {
            const model = await this.service.$test.retrieve(id);
            if (!model?.id) throw new Error(`404 NOT FOUND - invalid id[${id}] @${errScope}`);
            return this.modelAsView<TestView>(model);
        }

        // otherwise, error.
        throw new Error(`@id[${id}] is invalid - ${errScope}`);
    };
}

//*export as default.
export default new HelloAPIController();
