
import React, { useState, useCallback } from 'react';
import { generateBlogContent } from './services/geminiService';
import type { GeneratedContent } from './types';
import { KeywordForm } from './components/KeywordForm';
import { ResultsDisplay } from './components/ResultsDisplay';
import { Loader } from './components/Loader';
import { ErrorMessage } from './components/ErrorMessage';
import { InitialState } from './components/InitialState';

const App: React.FC = () => {
  const [keyword, setKeyword] = useState<string>('');
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!keyword.trim()) {
      setError('키워드를 입력해주세요.');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    try {
      const content = await generateBlogContent(keyword);
      setGeneratedContent(content);
    } catch (err) {
      console.error(err);
      setError('콘텐츠 생성 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    } finally {
      setIsLoading(false);
    }
  }, [keyword]);

  const renderContent = () => {
    if (isLoading) {
      return <Loader />;
    }
    if (error) {
      return <ErrorMessage message={error} />;
    }
    if (generatedContent) {
      return <ResultsDisplay content={generatedContent} />;
    }
    return <InitialState />;
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-3xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-2">
            AI 블로그 콘텐츠 생성기
          </h1>
          <p className="text-slate-400 text-lg">
            키워드 하나로 시선을 사로잡는 제목과 필수 태그를 만들어보세요.
          </p>
        </header>

        <main>
          <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-2xl border border-slate-700">
            <KeywordForm
              keyword={keyword}
              setKeyword={setKeyword}
              onGenerate={handleGenerate}
              isLoading={isLoading}
            />
          </div>
          <div className="mt-8 transition-all duration-500">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
