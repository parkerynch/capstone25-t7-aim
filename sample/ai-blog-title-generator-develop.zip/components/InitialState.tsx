
import React from 'react';

export const InitialState: React.FC = () => {
  return (
    <div className="text-center p-8 bg-slate-800/30 border border-dashed border-slate-700 rounded-lg">
      <div className="w-16 h-16 text-slate-500 mx-auto mb-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3c7.2 0 9 1.8 9 9s-1.8 9-9 9-9-1.8-9-9 1.8-9 9-9Z"></path>
            <path d="M8 12h8"></path>
            <path d="M12 8v8"></path>
        </svg>
      </div>
      <h3 className="text-xl font-semibold text-slate-300">결과가 여기에 표시됩니다</h3>
      <p className="text-slate-400 mt-2">
        위 입력창에 블로그 주제와 관련된 키워드를 입력하고<br/>'콘텐츠 생성' 버튼을 눌러주세요.
      </p>
    </div>
  );
};
