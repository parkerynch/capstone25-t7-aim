
import React from 'react';

export const Loader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center">
      <div className="w-12 h-12 border-4 border-t-transparent border-cyan-400 rounded-full animate-spin"></div>
      <p className="mt-4 text-slate-400 text-lg">AI가 열심히 콘텐츠를 만들고 있어요...</p>
    </div>
  );
};
