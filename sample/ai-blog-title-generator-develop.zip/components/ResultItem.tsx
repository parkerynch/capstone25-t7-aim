
import React, { useState, useCallback } from 'react';

interface ResultItemProps {
  text: string;
  isTag?: boolean;
}

const CopyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
  </svg>
);

const CheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);


export const ResultItem: React.FC<ResultItemProps> = ({ text, isTag = false }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [text]);

  if (isTag) {
    return (
      <div className="flex items-center gap-2 bg-slate-700/60 text-slate-200 text-sm font-medium px-3 py-1.5 rounded-full cursor-pointer hover:bg-slate-700 transition-colors" onClick={handleCopy}>
        <span>#{text}</span>
        <button className="text-slate-400 hover:text-white">
          {copied ? <CheckIcon className="w-3 h-3 text-green-400"/> : <CopyIcon className="w-3 h-3"/>}
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between bg-slate-800 p-4 rounded-lg border border-slate-700 hover:border-cyan-500 transition-all duration-300 group">
      <p className="text-slate-200 flex-grow pr-4">{text}</p>
      <button
        onClick={handleCopy}
        className="flex-shrink-0 p-2 rounded-md bg-slate-700 text-slate-400 hover:bg-cyan-500 hover:text-white transition-all duration-300"
        aria-label="Copy to clipboard"
      >
        {copied ? <CheckIcon className="w-5 h-5" /> : <CopyIcon className="w-5 h-5" />}
      </button>
    </div>
  );
};
