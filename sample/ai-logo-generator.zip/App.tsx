
import React, { useState, useCallback } from 'react';
import { Logo } from './types';
import { generateLogosAndRationales } from './services/geminiService';
import { LogoCard } from './components/LogoCard';
import { Loader } from './components/Loader';
import { SparklesIcon, ExclamationTriangleIcon } from './components/Icons';

const App: React.FC = () => {
    const [brandConcept, setBrandConcept] = useState<string>('');
    const [services, setServices] = useState<string>('');
    const [coreValues, setCoreValues] = useState<string>('');
    const [logos, setLogos] = useState<Logo[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = useCallback(async () => {
        if (!brandConcept || !services || !coreValues) {
            setError('Please fill out all fields to generate logos.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setLogos([]);
        try {
            const generatedLogos = await generateLogosAndRationales(brandConcept, services, coreValues);
            setLogos(generatedLogos);
        } catch (err) {
            console.error(err);
            setError('Failed to generate logos. The model may be unavailable. Please try again later.');
        } finally {
            setIsLoading(false);
        }
    }, [brandConcept, services, coreValues]);

    const isFormIncomplete = !brandConcept || !services || !coreValues;

    return (
        <div className="min-h-screen bg-gray-900 text-gray-200">
            <main className="container mx-auto px-4 py-8 md:py-12">
                <header className="text-center mb-10 md:mb-16">
                    <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600 mb-2">
                        LogoCraft AI
                    </h1>
                    <p className="text-md md:text-lg text-gray-400 max-w-2xl mx-auto">
                        Describe your brand, and our AI will craft unique logos with detailed design rationales.
                    </p>
                </header>

                <div className="max-w-3xl mx-auto bg-gray-800/50 rounded-2xl p-6 md:p-8 shadow-2xl border border-gray-700/50 backdrop-blur-sm">
                    <div className="grid grid-cols-1 gap-6">
                        <div>
                            <label htmlFor="brand-concept" className="block text-sm font-medium text-gray-300 mb-2">Brand/Team Concept</label>
                            <textarea
                                id="brand-concept"
                                rows={2}
                                value={brandConcept}
                                onChange={(e) => setBrandConcept(e.target.value)}
                                placeholder="e.g., 'Apex Innovations', a forward-thinking tech startup"
                                className="w-full bg-gray-900/70 border border-gray-700 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300"
                            />
                        </div>
                        <div>
                            <label htmlFor="services" className="block text-sm font-medium text-gray-300 mb-2">What you do (Services/Products)</label>
                            <textarea
                                id="services"
                                rows={3}
                                value={services}
                                onChange={(e) => setServices(e.target.value)}
                                placeholder="e.g., We build cutting-edge AI-powered analytics tools for businesses."
                                className="w-full bg-gray-900/70 border border-gray-700 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300"
                            />
                        </div>
                        <div>
                            <label htmlFor="core-values" className="block text-sm font-medium text-gray-300 mb-2">Core Values</label>
                            <textarea
                                id="core-values"
                                rows={2}
                                value={coreValues}
                                onChange={(e) => setCoreValues(e.target.value)}
                                placeholder="e.g., Innovation, Precision, Trust"
                                className="w-full bg-gray-900/70 border border-gray-700 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300"
                            />
                        </div>
                    </div>
                    <div className="mt-8 text-center">
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || isFormIncomplete}
                            className="inline-flex items-center justify-center px-8 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-purple-500/50"
                        >
                            <SparklesIcon className="w-5 h-5 mr-2" />
                            {isLoading ? 'Generating...' : 'Generate Logos'}
                        </button>
                    </div>
                </div>
                
                {isLoading && <Loader />}

                {error && (
                    <div className="mt-10 max-w-3xl mx-auto bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg flex items-center">
                        <ExclamationTriangleIcon className="w-5 h-5 mr-3" />
                        <span>{error}</span>
                    </div>
                )}

                {!isLoading && logos.length > 0 && (
                     <div className="mt-12 md:mt-16">
                        <h2 className="text-3xl font-bold text-center mb-8">Your AI-Generated Logo Concepts</h2>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            {logos.map((logo) => (
                                <LogoCard key={logo.id} logo={logo} />
                            ))}
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};

export default App;
