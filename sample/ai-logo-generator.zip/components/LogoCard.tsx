
import React from 'react';
import type { Logo } from '../types';
import { SymbolIcon, PaletteIcon, TypographyIcon } from './Icons';

interface LogoCardProps {
    logo: Logo;
}

export const LogoCard: React.FC<LogoCardProps> = ({ logo }) => {
    return (
        <div className="bg-gray-800/60 rounded-xl overflow-hidden shadow-lg border border-gray-700/50 transition-all duration-300 hover:shadow-indigo-500/20 hover:border-indigo-500/50">
            <div className="p-6 bg-gray-900 flex items-center justify-center aspect-square">
                <img 
                    src={logo.imageUrl} 
                    alt={`AI-generated logo concept ${logo.id + 1}`} 
                    className="max-w-full max-h-full object-contain rounded-lg" 
                />
            </div>
            <div className="p-6">
                <h3 className="text-xl font-bold text-gray-100 mb-4">Design Rationale</h3>
                <div className="space-y-4 text-gray-300">
                    <div className="flex items-start">
                        <SymbolIcon className="w-5 h-5 mr-3 mt-1 flex-shrink-0 text-purple-400" />
                        <div>
                            <h4 className="font-semibold text-gray-100">Symbolism</h4>
                            <p className="text-sm">{logo.rationale.symbolism}</p>
                        </div>
                    </div>
                    <div className="flex items-start">
                        <PaletteIcon className="w-5 h-5 mr-3 mt-1 flex-shrink-0 text-purple-400" />
                        <div>
                            <h4 className="font-semibold text-gray-100">Color Palette</h4>
                            <p className="text-sm">{logo.rationale.colorPalette}</p>
                        </div>
                    </div>
                    <div className="flex items-start">
                        <TypographyIcon className="w-5 h-5 mr-3 mt-1 flex-shrink-0 text-purple-400" />
                        <div>
                            <h4 className="font-semibold text-gray-100">Typography</h4>
                            <p className="text-sm">{logo.rationale.typography}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
