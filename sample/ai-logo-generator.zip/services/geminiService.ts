
import { GoogleGenAI, Type } from "@google/genai";
import { Logo, Rationale } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const NUM_LOGOS_TO_GENERATE = 4;

export const generateLogosAndRationales = async (brandConcept: string, services: string, coreValues: string): Promise<Logo[]> => {
    try {
        const imagePromise = generateLogoImages(brandConcept, services, coreValues);
        const rationalePromise = generateLogoRationales(brandConcept, services, coreValues);

        const [imageResponse, rationaleResponse] = await Promise.all([imagePromise, rationalePromise]);

        const imageUrls = imageResponse.generatedImages.map(img => `data:image/png;base64,${img.image.imageBytes}`);
        
        let rationales: Rationale[] = [];
        const rationaleText = rationaleResponse.text.trim();
        try {
            rationales = JSON.parse(rationaleText);
        } catch(e) {
            console.error("Failed to parse rationales JSON:", rationaleText);
            // Fallback: create placeholder rationales if parsing fails
            rationales = Array(NUM_LOGOS_TO_GENERATE).fill({
                symbolism: "AI was unable to generate a rationale for this design.",
                colorPalette: "Please try generating again with a more specific prompt.",
                typography: "Ensure your brand concepts are clear and distinct."
            });
        }

        if (imageUrls.length !== rationales.length) {
            console.warn("Mismatch between number of generated images and rationales.");
        }

        const combinedLogos: Logo[] = imageUrls.map((url, index) => ({
            id: index,
            imageUrl: url,
            rationale: rationales[index] || rationales[0], // Fallback to first rationale
        }));

        return combinedLogos;
    } catch (error) {
        console.error("Error in generateLogosAndRationales:", error);
        throw new Error("Failed to communicate with the AI models.");
    }
};

const generateLogoImages = (brandConcept: string, services: string, coreValues: string) => {
    const prompt = `
        Generate a professional, modern logo for a brand named "${brandConcept}".
        This brand's business is: "${services}".
        Their core values are: "${coreValues}".

        **Design Style Requirements:**
        - Style: Minimalist, iconic, abstract, vector art.
        - Background: Plain white background.
        - Format: Clean, scalable, suitable for both digital and print media.
        - Avoid complex gradients and photorealism. The logo should be a symbol or an abstract mark.
    `;

    return ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt,
        config: {
            numberOfImages: NUM_LOGOS_TO_GENERATE,
            outputMimeType: 'image/png',
            aspectRatio: '1:1',
        },
    });
};

const generateLogoRationales = (brandConcept: string, services: string, coreValues: string) => {
    const prompt = `
        You are a professional brand strategist.
        A brand has the following attributes:
        - Concept: "${brandConcept}"
        - Services: "${services}"
        - Core Values: "${coreValues}"

        Based on these attributes, generate ${NUM_LOGOS_TO_GENERATE} distinct logo design rationales. For each rationale, provide a concise explanation for the symbolism, color palette, and typography choices that would be fitting for a logo concept.
        
        Respond with ONLY a valid JSON array. Each object in the array should have three keys: "symbolism", "colorPalette", and "typography", each with a string value.
        Do not include any text, markdown formatting, or explanations outside of the JSON array itself.
    `;

    return ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        symbolism: { type: Type.STRING, description: 'Explanation of the symbols and shapes used.' },
                        colorPalette: { type: Type.STRING, description: 'Rationale for the color choices.' },
                        typography: { type: Type.STRING, description: 'Description of a suitable font style.' },
                    },
                    required: ['symbolism', 'colorPalette', 'typography'],
                },
            },
        },
    });
};
