
export interface Rationale {
  symbolism: string;
  colorPalette: string;
  typography: string;
}

export interface Logo {
  id: number;
  imageUrl: string;
  rationale: Rationale;
}
