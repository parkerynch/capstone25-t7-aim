
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { IngredientInput } from './components/IngredientInput';
import { RecipeList } from './components/RecipeList';
import { LoadingSpinner } from './components/LoadingSpinner';
import { getRecipesFromIngredients } from './services/geminiService';
import { Recipe } from './types';

const App: React.FC = () => {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  const handleFindRecipes = useCallback(async (ingredients: string) => {
    if (!ingredients.trim()) {
      setError("Please enter some ingredients.");
      return;
    }
    setIsLoading(true);
    setHasSearched(true);
    setError(null);
    setRecipes([]);

    try {
      const result = await getRecipesFromIngredients(ingredients);
      if (result && result.recipes) {
        setRecipes(result.recipes);
      } else {
        setError("Could not find any recipes. Try different ingredients.");
      }
    } catch (e) {
      console.error(e);
      setError("An error occurred while fetching recipes. Please check your API key and try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }
    if (error) {
      return <div className="text-center text-red-500 bg-red-100 p-4 rounded-lg">{error}</div>;
    }
    if (hasSearched && recipes.length === 0) {
      return (
        <div className="text-center text-gray-500">
          <p>No recipes found for the ingredients provided.</p>
          <p>Try being more specific or adding more items!</p>
        </div>
      );
    }
    if (recipes.length > 0) {
      return <RecipeList recipes={recipes} />;
    }
    return (
      <div className="text-center text-gray-500 py-10">
        <h2 className="text-2xl font-semibold text-stone-700">Ready to Cook?</h2>
        <p className="mt-2">Enter the ingredients you have on hand to discover your next meal.</p>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-stone-800">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <IngredientInput onSubmit={handleFindRecipes} isLoading={isLoading} />
          <div className="mt-12">
            {renderContent()}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
