
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white mt-12 py-4 shadow-inner">
      <div className="container mx-auto px-4 text-center text-sm text-stone-500">
        <p>Powered by the Google Gemini API</p>
      </div>
    </footer>
  );
};
