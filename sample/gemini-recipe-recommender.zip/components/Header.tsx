
import React from 'react';

const ChefHatIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 1.62.48 3.13 1.29 4.42.22.35.21.79-.04 1.13s-.65.55-1.05.55H4c-1.1 0-2 .9-2 2v2c0 1.1.9 2 2 2h1v-2H4v-1c0-.28.22-.5.5-.5h1.2c.47 0 .92-.21 1.2-.55.28-.34.4-.78.3-1.21C6.5 11.23 6 10.16 6 9c0-3.31 2.69-6 6-6s6 2.69 6 6c0 1.16-.5 2.23-1.2 3.04-.1.43-.02.87.3 1.21.28.34.73.55 1.2.55H20c.28 0 .5.22.5.5v1h-1v2h1c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2h-1.2c-.4 0-.81-.21-1.05-.55s-.26-.78-.04-1.13C18.52 12.13 19 10.62 19 9c0-3.87-3.13-7-7-7zm-1 14h2v2h-2v-2z" />
    </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center justify-center">
        <ChefHatIcon className="w-8 h-8 text-orange-500 mr-3" />
        <h1 className="text-3xl font-bold text-stone-800 tracking-tight">
          Gemini Recipe Recommender
        </h1>
      </div>
    </header>
  );
};
