
import React, { useState } from 'react';

interface IngredientInputProps {
  onSubmit: (ingredients: string) => void;
  isLoading: boolean;
}

export const IngredientInput: React.FC<IngredientInputProps> = ({ onSubmit, isLoading }) => {
  const [ingredients, setIngredients] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(ingredients);
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold text-stone-700 mb-4 text-center">What's in your kitchen?</h2>
        <form onSubmit={handleSubmit}>
        <textarea
          className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-orange-400 transition-shadow duration-200"
          placeholder="e.g., chicken breast, rice, broccoli, soy sauce"
          value={ingredients}
          onChange={(e) => setIngredients(e.target.value)}
          disabled={isLoading}
        />
        <button
          type="submit"
          className="mt-4 w-full bg-orange-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:bg-orange-300 disabled:cursor-not-allowed transition-colors duration-300 flex items-center justify-center"
          disabled={isLoading}
        >
          {isLoading ? 'Searching...' : 'Find Recipes'}
        </button>
      </form>
    </div>
  );
};
