
import React from 'react';
import { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
}

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
);

const ShoppingCartIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
    </svg>
);


export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
      <div className="p-6 md:p-8">
        <h3 className="text-2xl font-bold text-orange-600">{recipe.name}</h3>
        <p className="mt-2 text-stone-600 italic">{recipe.description}</p>
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-lg font-semibold text-stone-700 border-b-2 border-orange-200 pb-2 mb-3">Ingredients</h4>
            <ul className="space-y-2">
              {recipe.ingredients.map((ing, index) => (
                <li key={index} className={`flex items-start ${ing.have ? 'text-green-700' : 'text-stone-500'}`}>
                    {ing.have ? <CheckIcon className="w-5 h-5 mr-2 mt-0.5 flex-shrink-0" /> : <ShoppingCartIcon className="w-5 h-5 mr-2 mt-0.5 flex-shrink-0" />}
                    <span>{ing.item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold text-stone-700 border-b-2 border-orange-200 pb-2 mb-3">Instructions</h4>
            <ol className="list-decimal list-inside space-y-2 text-stone-700">
              {recipe.instructions.map((step, index) => (
                <li key={index} className="pl-2">{step}</li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
