
import React from 'react';
import { RecipeCard } from './RecipeCard';
import { Recipe } from '../types';

interface RecipeListProps {
  recipes: Recipe[];
}

export const RecipeList: React.FC<RecipeListProps> = ({ recipes }) => {
  return (
    <div className="space-y-8">
      {recipes.map((recipe, index) => (
        <RecipeCard key={`${recipe.name}-${index}`} recipe={recipe} />
      ))}
    </div>
  );
};
