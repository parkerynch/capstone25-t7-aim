
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiResponse } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const recipeSchema = {
    type: Type.OBJECT,
    properties: {
        recipes: {
            type: Type.ARRAY,
            description: "An array of 1 to 3 recipe suggestions.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: {
                        type: Type.STRING,
                        description: "The name of the dish."
                    },
                    description: {
                        type: Type.STRING,
                        description: "A short, enticing one-sentence description of the dish."
                    },
                    ingredients: {
                        type: Type.ARRAY,
                        description: "All ingredients needed for the recipe.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                item: {
                                    type: Type.STRING,
                                    description: "The ingredient name and quantity, e.g., '2 cups flour'."
                                },
                                have: {
                                    type: Type.BOOLEAN,
                                    description: "True if this ingredient was likely in the user's provided list, false otherwise."
                                }
                            },
                            required: ['item', 'have']
                        }
                    },
                    instructions: {
                        type: Type.ARRAY,
                        description: "Step-by-step cooking instructions.",
                        items: {
                            type: Type.STRING,
                            description: "A single step in the cooking instructions."
                        }
                    }
                },
                required: ['name', 'description', 'ingredients', 'instructions']
            }
        }
    },
    required: ['recipes']
};

export const getRecipesFromIngredients = async (ingredients: string): Promise<GeminiResponse> => {
    const prompt = `
        You are a helpful and creative culinary assistant.
        Based on the following list of ingredients, suggest 1 to 3 diverse recipes.
        
        Ingredients I have: ${ingredients}

        For each recipe, provide a name, a short description, a complete list of ingredients (clearly indicating which ones I already have), and step-by-step instructions.
        The user-provided ingredients might be messy, so please clean them up and match them intelligently. For example, if the user provides "chicken", you can match it to "chicken breast".
        If a core ingredient is missing for a great recipe, feel free to suggest it and mark it as something the user needs to acquire.
        Ensure the output is valid JSON that adheres to the provided schema.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: recipeSchema,
                temperature: 0.7,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedResponse = JSON.parse(jsonText);

        if (!parsedResponse || !Array.isArray(parsedResponse.recipes)) {
            throw new Error("Invalid response format from Gemini API.");
        }

        return parsedResponse as GeminiResponse;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to fetch recipes from the Gemini API.");
    }
};
