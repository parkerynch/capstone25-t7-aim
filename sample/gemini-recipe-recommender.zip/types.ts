
export interface Ingredient {
  item: string;
  have: boolean;
}

export interface Recipe {
  name: string;
  description: string;
  ingredients: Ingredient[];
  instructions: string[];
}

export interface GeminiResponse {
  recipes: Recipe[];
}
