
import React, { useState, useCallback, useRef, DragEvent } from 'react';
import type { ImageFile } from './types';
import { fileToBase64, generateImage } from './services/geminiService';

// === HELPER COMPONENTS (defined outside main App to prevent re-renders) ===

const Header: React.FC = () => (
  <header className="w-full p-4 border-b border-gray-200 bg-white">
    <div className="max-w-7xl mx-auto flex items-center gap-3">
      <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-bold text-xl">
        A
      </div>
      <h1 className="text-2xl font-bold text-slate-900">Interior AI Designer</h1>
    </div>
  </header>
);

const Spinner: React.FC = () => (
  <div className="border-4 border-gray-200 border-t-slate-600 rounded-full w-12 h-12 animate-spin"></div>
);

const SparkleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M9 4.5a.75.75 0 01.75.75v3.546a.75.75 0 01-1.5 0V5.25A.75.75 0 019 4.5zM12.75 8.634a.75.75 0 00-1.5 0v2.484a.75.75 0 001.5 0V8.634zM12 1.5a.75.75 0 01.75.75v3.085a.75.75 0 01-1.5 0V2.25A.75.75 0 0112 1.5zM15 6.204a.75.75 0 00-1.5 0v2.516a.75.75 0 001.5 0V6.204zM15.75 2.893a.75.75 0 01.622 1.341l-2.227 3.856a.75.75 0 01-1.244-.714l2.227-3.856a.75.75 0 01.622-.627zM6.53 8.083a.75.75 0 00-1.244.714l2.227 3.856a.75.75 0 101.244-.714L6.53 8.083zM18.12 10.155a.75.75 0 011.299-.75l1.624 2.813a.75.75 0 01-1.299.75l-1.624-2.813zM4.179 12.215a.75.75 0 00-1.299.75l1.624 2.813a.75.75 0 001.299-.75L4.18 12.215zM12 15a.75.75 0 01.75.75v3.466a.75.75 0 01-1.5 0v-3.466A.75.75 0 0112 15z" clipRule="evenodd" />
    </svg>
);


interface ImageDisplayProps {
  title: string;
  imageSrc: string | null;
  isLoading?: boolean;
}
const ImageDisplay: React.FC<ImageDisplayProps> = ({ title, imageSrc, isLoading = false }) => (
  <div className="w-full bg-white rounded-lg border border-gray-200 shadow-sm p-4 flex flex-col">
    <h2 className="text-xl font-semibold text-slate-800 mb-4">{title}</h2>
    <div className="relative flex-grow bg-gray-100 rounded-md flex items-center justify-center min-h-[300px] md:min-h-[400px]">
      {isLoading && (
        <div className="absolute inset-0 bg-white/70 flex flex-col items-center justify-center z-10 rounded-md">
          <Spinner />
          <p className="mt-4 text-slate-600 font-medium">Generating your design...</p>
        </div>
      )}
      {imageSrc ? (
        <img src={imageSrc} alt={title} className="max-w-full max-h-full object-contain rounded-md" />
      ) : (
        !isLoading && <p className="text-slate-500">Your generated image will appear here</p>
      )}
    </div>
  </div>
);

interface PromptControlsProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
  isDisabled: boolean;
}
const PromptControls: React.FC<PromptControlsProps> = ({ prompt, setPrompt, onGenerate, isLoading, isDisabled }) => (
  <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-sm border-t border-gray-200">
    <div className="max-w-4xl mx-auto p-4 flex flex-col sm:flex-row items-center gap-4">
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="e.g., 'Make the walls light blue and add a modern sofa'"
        className="w-full flex-grow p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-slate-500 focus:border-slate-500 transition resize-none"
        rows={2}
        disabled={isDisabled}
      />
      <button
        onClick={onGenerate}
        disabled={isLoading || isDisabled || !prompt.trim()}
        className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-slate-900 text-white font-semibold rounded-lg shadow-md hover:bg-slate-700 disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors duration-200"
      >
        <SparkleIcon className="w-5 h-5" />
        {isLoading ? 'Generating...' : 'Generate'}
      </button>
    </div>
  </div>
);

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
}
const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload }) => {
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onImageUpload(file);
        }
    };

    const handleDrop = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(false);
        const file = event.dataTransfer.files?.[0];
        if (file && file.type.startsWith('image/')) {
            onImageUpload(file);
        }
    };
    
    const handleDragOver = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
    };

    const handleDragEnter = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(true);
    };

    const handleDragLeave = (event: DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(false);
    };

    return (
        <div className="flex-grow flex items-center justify-center p-8">
            <div 
                className={`w-full max-w-2xl p-12 border-2 border-dashed rounded-xl text-center cursor-pointer transition-colors ${isDragging ? 'border-slate-600 bg-slate-100' : 'border-gray-300 bg-white'}`}
                onClick={() => fileInputRef.current?.click()}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragEnter={handleDragEnter}
                onDragLeave={handleDragLeave}
            >
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                />
                <div className="flex flex-col items-center justify-center text-slate-600">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mb-4 text-gray-400">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                    </svg>
                    <p className="font-semibold text-xl">Upload an image of your room</p>
                    <p className="mt-2 text-sm">Click to browse or drag and drop an image file here</p>
                </div>
            </div>
        </div>
    );
};


// === MAIN APP COMPONENT ===

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<ImageFile | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setOriginalImage({ file, dataURL: reader.result as string });
      setEditedImage(null);
      setError(null);
      setPrompt('');
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = useCallback(async () => {
    if (!originalImage || !prompt.trim()) {
      setError("Please ensure you have an image uploaded and a prompt written.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setEditedImage(null);

    try {
      const { data, mimeType } = await fileToBase64(originalImage.file);
      const result = await generateImage(prompt, data, mimeType);
      setEditedImage(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, prompt]);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <Header />
      <main className="flex-grow w-full max-w-7xl mx-auto p-4 md:p-8 pb-32">
        {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
            </div>
        )}

        {!originalImage ? (
          <ImageUploader onImageUpload={handleImageUpload} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ImageDisplay title="Original" imageSrc={originalImage.dataURL} />
            <ImageDisplay title="Generated" imageSrc={editedImage} isLoading={isLoading} />
          </div>
        )}
      </main>
      <PromptControls 
        prompt={prompt}
        setPrompt={setPrompt}
        onGenerate={handleGenerate}
        isLoading={isLoading}
        isDisabled={!originalImage}
      />
    </div>
  );
};

export default App;
