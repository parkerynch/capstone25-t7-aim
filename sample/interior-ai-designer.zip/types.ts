
export interface ImageFile {
  file: File;
  dataURL: string;
}
