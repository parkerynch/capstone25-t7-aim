
import React, { useState, useCallback } from 'react';
import { SummaryLength } from './types';
import { summarizeText } from './services/geminiService';
import Header from './components/Header';
import TextAreaInput from './components/TextAreaInput';
import LengthSelector from './components/LengthSelector';
import SummarizeButton from './components/SummarizeButton';
import SummaryOutput from './components/SummaryOutput';
import ErrorDisplay from './components/ErrorDisplay';

function App() {
  const [articleText, setArticleText] = useState<string>('');
  const [summaryLength, setSummaryLength] = useState<SummaryLength>(SummaryLength.Short);
  const [summary, setSummary] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSummarize = useCallback(async () => {
    if (!articleText.trim()) {
      setError('Please paste an article to summarize.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setSummary('');

    try {
      const result = await summarizeText(articleText, summaryLength);
      setSummary(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [articleText, summaryLength]);

  return (
    <div className="min-h-screen font-sans text-gray-800 dark:text-gray-200">
      <Header />
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-12">
          {/* Input Section */}
          <div className="flex flex-col space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Article Content</h2>
            <TextAreaInput
              value={articleText}
              onChange={(e) => setArticleText(e.target.value)}
              placeholder="Paste your news article here..."
              disabled={isLoading}
            />
            <LengthSelector
              selectedValue={summaryLength}
              onChange={setSummaryLength}
              disabled={isLoading}
            />
            <SummarizeButton
              onClick={handleSummarize}
              isLoading={isLoading}
              disabled={!articleText.trim()}
            />
             {error && <ErrorDisplay message={error} />}
          </div>

          {/* Output Section */}
          <div className="mt-12 lg:mt-0">
             <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Summary</h2>
             <SummaryOutput
                summary={summary}
                isLoading={isLoading}
             />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
