
import React from 'react';
import { SummaryLength } from '../types';

interface LengthSelectorProps {
  selectedValue: SummaryLength;
  onChange: (value: SummaryLength) => void;
  disabled: boolean;
}

const options = [
  { value: SummaryLength.Short, label: '3 Sentences' },
  { value: SummaryLength.Medium, label: '5 Sentences' },
  { value: SummaryLength.Long, label: 'Unlimited' },
];

const LengthSelector: React.FC<LengthSelectorProps> = ({ selectedValue, onChange, disabled }) => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3 text-gray-900 dark:text-white">Summary Length</h3>
      <div className="grid grid-cols-3 gap-2 sm:gap-4">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            disabled={disabled}
            className={`
              px-4 py-3 rounded-lg text-sm font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 dark:focus:ring-offset-gray-900 focus:ring-primary-500
              ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
              ${selectedValue === option.value
                ? 'bg-primary-600 text-white shadow-md'
                : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600 border border-gray-200 dark:border-gray-600'
              }
            `}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default LengthSelector;
