
import React from 'react';
import Loader from './Loader';
import SparklesIcon from './icons/SparklesIcon';

interface SummarizeButtonProps {
  onClick: () => void;
  isLoading: boolean;
  disabled: boolean;
}

const SummarizeButton: React.FC<SummarizeButtonProps> = ({ onClick, isLoading, disabled }) => {
  const isDisabled = isLoading || disabled;

  return (
    <button
      onClick={onClick}
      disabled={isDisabled}
      className={`
        w-full flex items-center justify-center px-6 py-4 border border-transparent text-base font-medium rounded-md text-white
        transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500
        ${isDisabled
          ? 'bg-gray-400 dark:bg-gray-600 cursor-not-allowed'
          : 'bg-primary-600 hover:bg-primary-700 transform hover:scale-105'
        }
      `}
    >
      {isLoading ? (
        <>
          <Loader className="h-5 w-5 mr-3" />
          Summarizing...
        </>
      ) : (
        <>
          <SparklesIcon className="h-5 w-5 mr-2" />
          Summarize
        </>
      )}
    </button>
  );
};

export default SummarizeButton;
