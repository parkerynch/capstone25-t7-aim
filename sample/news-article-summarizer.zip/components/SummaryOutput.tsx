
import React from 'react';
import Loader from './Loader';

interface SummaryOutputProps {
  summary: string;
  isLoading: boolean;
}

const SummaryOutput: React.FC<SummaryOutputProps> = ({ summary, isLoading }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg w-full min-h-[24rem] flex flex-col p-6">
      {isLoading ? (
        <div className="flex-grow flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
          <Loader className="h-10 w-10 mb-4" />
          <p className="text-lg font-medium">Generating summary...</p>
          <p className="text-sm">This may take a moment.</p>
        </div>
      ) : summary ? (
        <div className="prose prose-lg dark:prose-invert max-w-none text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed">
          {summary}
        </div>
      ) : (
        <div className="flex-grow flex flex-col items-center justify-center text-center text-gray-500 dark:text-gray-400">
          <svg className="h-12 w-12 mx-auto mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" />
          </svg>
          <p className="text-lg font-semibold">Your summary will appear here</p>
          <p className="text-sm mt-1">Paste an article, select a length, and click "Summarize".</p>
        </div>
      )}
    </div>
  );
};

export default SummaryOutput;
