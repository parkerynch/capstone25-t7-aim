
import { GoogleGenAI } from "@google/genai";
import { SummaryLength } from '../types';

const getLengthInstruction = (length: SummaryLength): string => {
  switch (length) {
    case SummaryLength.Short:
      return 'in exactly 3 sentences';
    case SummaryLength.Medium:
      return 'in exactly 5 sentences';
    case SummaryLength.Long:
      return 'as a detailed but concise paragraph, without a specific sentence limit';
    default:
      return 'as a concise paragraph';
  }
};

export const summarizeText = async (articleText: string, summaryLength: SummaryLength): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `
      You are an expert news article summarizer.
      Your task is to analyze the language of the following news article and summarize it in the SAME language.
      The summary should be ${getLengthInstruction(summaryLength)}.
      Optimize the summary for maximum readability, clarity, and conciseness, as if for a news briefing.
      Do not add any introductory phrases like "The article discusses...", "This text is about...", or "Summary:". Directly provide the summary.

      ARTICLE:
      ---
      ${articleText}
      ---
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error summarizing text:", error);
    throw new Error("Failed to generate summary. Please check your API key and network connection.");
  }
};
