
export enum SummaryLength {
  Short = '3-sentence',
  Medium = '5-sentence',
  Long = 'unlimited',
}
